function bigImgRei(x) {
    x.style.width = "160px";
}
  
function normalImgRei(x) {
    x.style.width = "150px";
}

function bigImgMel(x) {
    x.style.width = "105px";
}
  
function normalImgMel(x) {
    x.style.width = "100px";
}

function bigImgles(x) {
    x.style.width = "150px";
}
  
function normalImgles(x) {
    x.style.width = "140px";
}

function bigImgde(x) {
    x.style.width = "130px";
}
  
function normalImgde(x) {
    x.style.width = "120px";
}

function bigImgap(x) {
    x.style.width = "220px";
}
  
function normalImgap(x) {
    x.style.width = "210px";
}